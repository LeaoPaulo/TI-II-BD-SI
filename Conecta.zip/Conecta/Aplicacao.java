package maven.project;
import java.util.*;

public class Aplicacao {
	
	public static void main(String[] args) throws Exception {
		
		UserDao userDao = new userDao();
		User user = new user();
		
		Scanner sc = new Scanner(System.in);
		int x = 0;

		do {
			
			System.out.println("1 - Listar\n2 - Inserir\n3 - Excluir\n4 - Atualizar\n5 - Sair\n");
			System.out.print("\nEscolha: ");
			x = sc.nextInt();
			
			while (x < 1 || x > 5) {
				System.out.println("\nerro\n");
				System.out.println("1=Listar\n2=Inserir\n3=Excluir\n4=Atualizar\n5=Sair\n");
				System.out.print("\nopcao: ");
				x = sc.nextInt();
			}
		    switch (x) {
		      case 1: userDao.get("id"); break;
		      case 2: userDao.inserirPessoa(userDao); break;
		      case 3: userDao.deletarPessoa(userDao); break;
		      case 4: userDao.update(pessoa); break;
		      case 5: userDao.finalize(); break;
	        }
		} while (x != 5 );
		
		sc.close();
	
	}
}